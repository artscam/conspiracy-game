#! /usr/bin/env python3

from conspiracy.engine import engine

engine.main()
